package com.virtusa.controllers;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.virtusa.DAO.HibernateUtils;
import com.virtusa.models.EmployeeData;


@Controller

public class LoginController {
	@RequestMapping("/Login") 
	public  String valid(HttpServletRequest req,Model model) {
		
		int id=Integer.parseInt(req.getParameter("empid"));
		String pass=req.getParameter("pwd");
		System.out.println(id+" "+pass);
		Session session  = HibernateUtils.getSession();
		 if(session==null)
			 System.out.println("null");
	      
	       try {
	              session.getTransaction().begin();
	              String hql = " from EmployeeData E where E.id= 8063579";
	              
	              Query query = session.createQuery(hql);
	              
	              /*query.setParameter("id1",id);*/
	              List<EmployeeData> results = query.list();
	              /*List < EmployeeData > students = session.createQuery("FROM EmployeeData E WHERE E.id =:id").list();*/
	              /*students.forEach(s-> System.out.println(s.getFirstName()));*/
	              System.out.print(results);
	              for(EmployeeData e: results) {
	            	  
	            	  System.out.println(e.getId()+" "+e.getPassword());
	              }
	              session.getTransaction().commit();}
	       catch(Exception ae) {
	    	   ae.printStackTrace();
	    	   System.out.println("Exception");
	       }
		return "";
	}
}
