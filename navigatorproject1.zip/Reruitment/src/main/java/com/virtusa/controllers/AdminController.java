package com.virtusa.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AdminController {
	@RequestMapping("/Admin")
	public  String homepage() {
		return "index";
	}
}
